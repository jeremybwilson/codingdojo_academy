function print1to255() {
  var arr = [];
  for(var i = 1; i < 256; i++) {
    arr.push(i);
  }
  return arr;
}
print1to255();
console.log(print1to255());
